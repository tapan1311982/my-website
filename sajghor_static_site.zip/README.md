# Sajghor — Static Starter (Free-host ready)

What you get:
- `index.html` — Homepage with product grid, slider, search, sort, admin quick-add (local-only), contact form (Netlify-ready), WhatsApp order button.
- `style.css` — Styles, responsive, animations.
- `script.js` — Product loading, slider, cart (localStorage), admin quick-add.
- `cart.html` — Cart page with WhatsApp checkout.
- `products.json` — Sample product data (for reference).

How to use:
1. Download and unzip the folder.
2. Edit `index.html` and replace `YOURNUMBER` in WhatsApp links with your mobile (91XXXXXXXXXX).
3. To add products permanently, edit `products.json` or edit `index.html` to point to a server endpoint. The built-in admin form saves locally in your browser (localStorage) for preview.
4. Host the folder on Netlify, GitHub Pages, or Vercel (static hosting). For Netlify, drag & drop the folder into Netlify's Deploy section.

Notes:
- The Quick Add product form only stores products to your browser for preview and is not a backend. For a production site you need a proper backend or use a static CMS (Netlify CMS, Cloudinary + GitHub, or Firebase).
- This starter is intentionally simple so it can be hosted for free and managed without a server.
