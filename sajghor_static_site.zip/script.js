/* Sajghor static site script:
   - Loads sample products (built-in + localStorage additions)
   - Simple slider
   - Cart using localStorage
   - Quick admin add (local only)
*/
const PRODUCTS_KEY = 'sajghor_products_v1';
const CART_KEY = 'sajghor_cart_v1';

const sampleProducts = [
  { id: 'p1', title: 'Premium T-shirt', price: 499, image: 'https://via.placeholder.com/600x800?text=T-Shirt' },
  { id: 'p2', title: 'Classic Kurti', price: 699, image: 'https://via.placeholder.com/600x800?text=Kurti' },
  { id: 'p3', title: 'Cozy Hoodie', price: 899, image: 'https://via.placeholder.com/600x800?text=Hoodie' },
  { id: 'p4', title: 'Silk Saree', price: 2499, image: 'https://via.placeholder.com/600x800?text=Saree' }
];

function loadProducts(){
  let local = JSON.parse(localStorage.getItem(PRODUCTS_KEY) || 'null');
  if(!local){
    localStorage.setItem(PRODUCTS_KEY, JSON.stringify(sampleProducts));
    local = sampleProducts;
  }
  return local;
}

function saveProducts(list){
  localStorage.setItem(PRODUCTS_KEY, JSON.stringify(list));
}

function renderProducts(filter=''){
  const grid = document.getElementById('products-grid');
  const sortEl = document.getElementById('sort');
  const sort = sortEl ? sortEl.value : 'new';
  let products = loadProducts().slice();
  if(filter) products = products.filter(p => p.title.toLowerCase().includes(filter.toLowerCase()));
  if(sort === 'low') products.sort((a,b)=>a.price-b.price);
  else if(sort === 'high') products.sort((a,b)=>b.price-a.price);
  else products.sort((a,b)=> (b.createdAt||0) - (a.createdAt||0));
  grid.innerHTML = '';
  products.forEach(p => {
    const el = document.createElement('div');
    el.className = 'card';
    el.innerHTML = `
      <img src="${p.image || 'https://via.placeholder.com/600x800?text=Product'}" alt="${p.title}" />
      <h3>${p.title}</h3>
      <p>₹${p.price}</p>
      <div class="actions">
        <button class="btn-outline" onclick='openWhats("${encodeURIComponent(p.title)}")'>WhatsApp</button>
        <button class="btn-primary" onclick='addToCart("${p.id}")'>Add to Cart</button>
      </div>
    `;
    grid.appendChild(el);
  });
  updateCartCount();
}

function openWhats(titleEncoded){
  const base = document.getElementById('whatsapp-template').href;
  window.open(base + encodeURIComponent(titleEncoded), '_blank');
}

function addToCart(productId){
  const products = loadProducts();
  const p = products.find(x=>x.id===productId);
  if(!p) return alert('Product not found');
  let cart = JSON.parse(localStorage.getItem(CART_KEY) || '[]');
  const exist = cart.find(it=>it.id===p.id);
  if(exist) exist.qty = (exist.qty||1) + 1; else cart.push({ id:p.id, title:p.title, price:p.price, qty:1 });
  localStorage.setItem(CART_KEY, JSON.stringify(cart));
  updateCartCount();
  alert(p.title + ' added to cart');
}

function updateCartCount(){
  const cart = JSON.parse(localStorage.getItem(CART_KEY) || '[]');
  const total = cart.reduce((s,i)=>s+(i.qty||1), 0);
  const el = document.getElementById('cart-count');
  if(el) el.textContent = total;
}

// Admin quick add
document.addEventListener('DOMContentLoaded', ()=>{
  renderProducts();
  document.getElementById('search')?.addEventListener('input', (e)=> renderProducts(e.target.value));
  document.getElementById('sort')?.addEventListener('change', ()=> renderProducts(document.getElementById('search')?.value || ''));

  const adminForm = document.getElementById('admin-form');
  adminForm?.addEventListener('submit', (e)=>{
    e.preventDefault();
    const fd = new FormData(adminForm);
    const title = fd.get('title').trim();
    const price = Number(fd.get('price'));
    const image = fd.get('image').trim() || ('https://via.placeholder.com/600x800?text=' + encodeURIComponent(title));
    if(!title || !price) return alert('Please provide title and price');
    const products = loadProducts();
    const id = 'p' + Date.now();
    products.unshift({ id, title, price, image, createdAt: Date.now() });
    saveProducts(products);
    renderProducts();
    adminForm.reset();
    alert('Product added (local preview only).');
  });

  // slider
  startSlider();
});

let sliderIndex = 0;
function startSlider(){
  const slider = document.getElementById('hero-slider');
  if(!slider) return;
  setInterval(()=>{
    sliderIndex = (sliderIndex + 1) % slider.children.length;
    slider.style.transform = `translateX(-${sliderIndex * 100}%)`;
  }, 3500);
}
